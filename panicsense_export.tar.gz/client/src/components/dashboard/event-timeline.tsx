import { DisasterTimeline } from "../timeline/disaster-timeline";

export function EventTimeline() {
  return (
    <div className="w-full">
      <DisasterTimeline />
    </div>
  );
}
